<?php
$this->load->view('vwHeader');
?>
<link href="<?php echo HTTP_CSS_PATH; ?>jumbotron.css" rel="stylesheet">
<div style="text-align: center;margin-top: 20px;">
    <img src="<?php echo base_url()."assets/img/maintain.png";?>"/>
</div>
<?php
$this->load->view('vwFooter');
?>