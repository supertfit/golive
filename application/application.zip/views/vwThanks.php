<?php
/*
 * Created on Aug 8, 2014
 *
 * To change the template for this generated file go to
 * Window - Preferences - PHPeclipse - PHP - Code Templates
 */
?>
<h1>Welcome to visit us!</h1>