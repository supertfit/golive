<?php
$this->load->view('vwHeader');
?>

<?php
$this->load->view('vwFooter');
?>